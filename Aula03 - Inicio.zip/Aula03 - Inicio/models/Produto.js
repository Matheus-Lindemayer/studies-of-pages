
const produtos = [];

module.exports = class Produto {

    constructor(nome, preco, descricao, imagem) {
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.imagem = imagem;
    }

    salvar() {
        produtos.push(this);
        console.log(produtos);
    }

    static buscarTodos() {
        return produtos;
    }

    
}